package tienda;

public class Cliente extends Persona {
    private static int compras; // Variable estática para realizar un seguimiento de las compras totales

    private String nombre; // Variable para almacenar el nombre del cliente
    private int cantID; // Variable para almacenar la cantidad de ID del cliente

    public Cliente(String nombre, int cantID, String apellido) {
        super(nombre, apellido); // Llamar al constructor de la clase padre (Persona) para establecer el nombre y el apellido
        this.nombre = nombre; // Asignar el nombre proporcionado al atributo 'nombre'
        this.cantID = cantID; // Asignar la cantidad de ID proporcionada al atributo 'cantID'
    }

    public String getNombre() {
        return nombre; // Devolver el nombre del cliente
    }

    public int getCantID() {
        return cantID; // Devolver la cantidad de ID del cliente
    }

    public void sumarCompras() {
        Cliente.compras++; // Incrementar el contador de compras totales para todos los clientes
    }

    public void mostrarCompras() {
        System.out.println(this.compras); // Mostrar el número de compras totales del cliente actual
    }

    public int getCompras() {
        return this.compras; // Devolver el número de compras totales del cliente actual
    }

    public void setCompras(int compras) {
        this.compras = compras; // Establecer el número de compras totales del cliente actual
    }

    @Override
    public String toString() {
        return "Nombre: " + this.nombre + "\n" + // Devolver una representación en cadena del cliente
                "Apellido" + this.apellido + "\n" +
                 "Cantidad de Pedidos: " + this.cantID + "\n" +
                 "Compras totales" + this.compras;
}

   
}

 



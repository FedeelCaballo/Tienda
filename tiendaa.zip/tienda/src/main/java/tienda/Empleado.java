
package tienda;

public class Empleado extends Persona{
    private float sueldo;

    public Empleado(String nombre, String apellido , float sueldo){
        super(nombre,apellido);
        this.sueldo=sueldo;
    }
}

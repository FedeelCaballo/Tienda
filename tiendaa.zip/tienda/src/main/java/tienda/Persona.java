package tienda;

public  class Persona {
    protected String nombres;
    protected String apellido;

public Persona(String nombre, String apellido){
    this.nombres=nombres;
    this.apellido=apellido;
}    
public String getNombres(){
    return this.nombres;
}

    public void setNombres(String nombre) {
        this.nombres = nombres;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

public String getApellido(){
    return this.apellido;
}
}


package tienda;
import java.util.ArrayList;

public class ejecutable {
    public static void main(String[] args) {
        Empleado el = new Empleado("Claudio","Mazzini", 50000);
       
        Cliente c1 = new Cliente ("Marcos",8 ,"Rodriguez");
       
        Desayuno d1 = new Desayuno ("facturas", "dulce de leche", 1440);
        Desayuno d2 = new Desayuno ("fosforos", "de jamon y queso", 2000);
       
        c1.setCompras(8);
        ArrayList<Desayuno> listaDesayunos = new ArrayList();
        listaDesayunos.add(d1);
        listaDesayunos.add(d2);
       
        compras compra = new compras(c1, listaDesayunos);
       
        System.out.println(compra.mostrarTicket());
       
    }
}

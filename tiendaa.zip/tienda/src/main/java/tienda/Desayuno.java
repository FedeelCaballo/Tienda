package tienda;

public class Desayuno {
    private String nombre; // Variable para almacenar el nombre del desayuno
    private String descripcion; // Variable para almacenar la descripción del desayuno
    private float precio; // Variable para almacenar el precio del desayuno

    public Desayuno(String nombre, String descripcion, float precio) {
        this.descripcion = descripcion; // Asignar la descripción proporcionada al atributo 'descripcion'
        this.precio = precio; // Asignar el precio proporcionado al atributo 'precio'
    }

    public String getNombre() {
        return this.nombre; // Devolver el nombre del desayuno
    }

    public String getDescripcion() {
        return this.descripcion; // Devolver la descripción del desayuno
    }

    public float getPrecio() {
        return this.precio; // Devolver el precio del desayuno
    }

    @Override
    public String toString() {
        return "Nombre del plato: " + this.nombre + "\n" + // Devolver una representación en cadena del desayuno
                "Descripcion: " + this.descripcion + "\n" +
                "Precio: " + this.precio;
    }
}
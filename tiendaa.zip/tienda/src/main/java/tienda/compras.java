package tienda;

import java.util.ArrayList;

public class compras {
    private Cliente cliente;
    private ArrayList<Desayuno> listaDesayunos = new ArrayList();
    private float importe;
   
public compras(Cliente cliente, ArrayList<Desayuno> listaDesayunos){
    this.cliente=cliente;
    this.importe=importe;
    this.listaDesayunos=listaDesayunos;
    this.cliente.sumarCompras();
}
public void añadirDesayuno(Desayuno d){
    listaDesayunos.add(d);
}
public float calcularTotal(){
    float preciototal = 0;
    float precio;
    for (int x = 0; x < listaDesayunos.size(); x++){
        precio = listaDesayunos.get(x).getPrecio();
        preciototal = preciototal + precio;
    }
    return preciototal;
}

public float calcularDescuento(){
    float descuento = 0;
    if (this.cliente.getCompras() % 10 == 0){
        this.importe=calcularTotal() - calcularTotal();
        descuento = this.calcularTotal();
    }else{
        this.importe=calcularTotal();
        descuento = 0;
    }
    return descuento;
}
public String mostrarTicket(){
    float descuento = 0;
    if (this.cliente.getCompras() % 10 == 0){
        this.importe=calcularTotal() - calcularTotal();
        descuento = this.calcularTotal();
    }else{
        this.importe=calcularTotal();
        descuento = 0;
    }
    String listadeDesayunos = "";
    for (int x = 0; x < listaDesayunos.size(); x++){
        String desayuno = listaDesayunos.get(x).toString();
        listadeDesayunos = listadeDesayunos + "\n" + desayuno + "\n";
    }
    return "Cliente: " + this.cliente.getNombre()
                + "\n" +
            "Lista de Desayunos: "
                + "\n" +
            listadeDesayunos
                + "\n" +
            "Descuento: " + calcularDescuento()
                + "\n" +
            "Precio total: " + this.importe;
}
}
